# Release verification

- Checked 9 retained coefficients, 1488 model-input records, 1478 archived scored records and 1310 patient-level scores.
- Checked 405 TCGA primary complete cases and all 920 archived cohort/model C-index entries.
- Score reconstruction, patient aggregation, eight-cohort C-index/HR and primary adjusted Cox HR checks passed.
- Maximum absolute discrepancy across the five checks: 9.33e-15.
- Six copied supplementary XLSX files passed archive integrity checks; no workbook content was edited.
- CSV row widths, data dictionary targets and Python syntax were checked.
- The three summary PDFs each contain one page and were rendered for visual inspection.
- No raw-data-to-all-figures run, original model redevelopment or original complete-environment restoration was performed.
