# Software environment
- The archived revision records report R 4.5.3 (2026-03-11 ucrt), Windows 11 x64 (build 26300), x86_64-w64-mingw32/x64, and LAPACK 3.12.1.
- R_package_versions_recorded.csv transcribes exact versions from four saved revision sessions. It is scoped evidence, not a complete historical lock.
- R_dependency_inventory.csv lists static imports across all nine original modules; blank versions are unavailable, not the latest release.
- The original Python version and package/database versions were not preserved in the inspected records. python_analysis_imports_unpinned.txt is an import inventory, not a pinned or install-tested historical environment.
- The lightweight scripts/reproduce_selected.R uses base R and the recommended survival package. plotting_sessionInfo.txt and plotting_environment_packages.csv document its actual export/verification environment. They do not describe every original analysis.
- Original CPU/RAM/GPU specifications, full system dependencies, thread settings for all R analyses and the full original dependency closure were not preserved.
- No historical renv.lock is fabricated. capture_environment.R and capture_python_environment.py can record a working analysis environment when run in the actual environment used for a module. Review generated files before public upload.
- R renv does not install the R interpreter or OS/system dependencies. External gene sets, annotations, pathway/drug databases and CellPhoneDB resources require their own documented release.
