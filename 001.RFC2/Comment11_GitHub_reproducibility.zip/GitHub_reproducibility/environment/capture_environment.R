# Run in the actual working analysis environment, preferably after completing the module.
args <- commandArgs(TRUE)
out <- if(length(args))args[1]else "environment/captured"
dir.create(out,recursive=TRUE,showWarnings=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,"sessionInfo.txt"))
p <- installed.packages()
write.csv(p[,c("Package","Version","Built"),drop=FALSE],file.path(out,"installed_R_packages.csv"),row.names=FALSE)
writeLines(capture.output(list(R=R.version.string,platform=R.version$platform,
    OS=Sys.info()[c("sysname","release","version","machine")],
    timezone=Sys.timezone(),locale=Sys.getlocale(),RNGkind=RNGkind())),
    file.path(out,"system_summary.txt"))
# Opt in only in an already configured, complete renv project:
if(identical(Sys.getenv("CAPTURE_RENV_LOCK"),"1")){
 if(!requireNamespace("renv",quietly=TRUE))stop("Install renv in the intended project first.")
 renv::snapshot(lockfile=file.path(out,"renv.lock"),prompt=FALSE)
}
