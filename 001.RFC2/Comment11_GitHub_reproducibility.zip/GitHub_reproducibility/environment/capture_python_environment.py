# Run with the Python interpreter actually used for the analysis.
from pathlib import Path
from importlib.metadata import distributions
import platform, sys
out = Path(sys.argv[1]) if len(sys.argv)>1 else Path("environment/captured")
out.mkdir(parents=True,exist_ok=True)
(out/"python_environment.txt").write_text(
    f"Python: {platform.python_version()}\nOS: {platform.platform()}\n",encoding="utf-8")
records=sorted({(d.metadata["Name"],d.version) for d in distributions() if d.metadata["Name"]})
(out/"requirements.txt").write_text("\n".join(f"{n}=={v}" for n,v in records)+"\n",encoding="utf-8")
