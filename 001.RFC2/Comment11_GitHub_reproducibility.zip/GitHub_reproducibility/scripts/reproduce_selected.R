# Run from any directory: Rscript scripts/reproduce_selected.R [repository_root]
args <- commandArgs(TRUE)
script_arg <- grep("^--file=",commandArgs(FALSE),value=TRUE)
default_root <- if(length(script_arg)) dirname(dirname(normalizePath(sub("^--file=","",script_arg[1]),winslash="/"))) else "."
root <- normalizePath(if(length(args))args[1]else default_root,winslash="/",mustWork=TRUE)
out <- file.path(root,"results","reproduced")
dir.create(out,recursive=TRUE,showWarnings=FALSE)
read_data <- function(name)read.csv(file.path(root,"data",name),check.names=FALSE,stringsAsFactors=FALSE)
write_result <- function(x,name)write.csv(x,file.path(out,name),row.names=FALSE,na="")
coef <- read_data("model_coefficients.csv")
x <- read_data("nine_gene_model_inputs.csv")
archived <- read_data("record_level_risk_scores.csv")
stopifnot(!anyDuplicated(coef$gene),all(coef$gene%in%names(x)))
x$RS_recomputed <- exp(drop(as.matrix(x[,coef$gene,drop=FALSE])%*%coef$coefficient))
key <- function(d,id)paste(d$cohort,d[[id]],sep="::")
stopifnot(!anyDuplicated(key(x,"sample_id")))
j <- match(key(archived,"sample_id"),key(x,"sample_id"))
stopifnot(!anyNA(j))
score_error <- max(abs(x$RS_recomputed[j]-archived$RS))
stopifnot(score_error<1e-10)
write_result(x,"recomputed_record_scores.csv")

# Mean linear predictor across repeated records; preserve the supplied public patient mapping.
mapping <- read_data("record_to_patient_map.csv")
j <- match(key(archived,"sample_id"),key(mapping,"sample_id"))
stopifnot(!anyNA(j),!anyDuplicated(key(mapping,"sample_id")))
archived$patient_id <- mapping$patient_id[j]
archived$log_RS <- log(x$RS_recomputed[match(key(archived,"sample_id"),key(x,"sample_id"))])
valid <- is.finite(archived$time_days)&archived$time_days>0&archived$event%in%c(0,1)
archived <- archived[valid,]
groups <- split(archived,paste(archived$cohort,archived$patient_id,sep="::"))
patient <- do.call(rbind,lapply(groups,function(d){
 stopifnot(length(unique(d$time_days))==1,length(unique(d$event))==1)
 data.frame(cohort=d$cohort[1],patient_id=d$patient_id[1],time_days=d$time_days[1],
            event=d$event[1],RS=exp(mean(d$log_RS)),n_records=nrow(d))
}))
rownames(patient)<-NULL
expected <- read_data("patient_level_risk_scores.csv")
j <- match(key(expected,"patient_id"),key(patient,"patient_id"))
stopifnot(!anyNA(j),nrow(expected)==nrow(patient),all(expected$n_records==patient$n_records[j]),
          all(expected$event==patient$event[j]),all(expected$time_days==patient$time_days[j]))
patient_error <- max(abs(expected$RS-patient$RS[j]))
stopifnot(patient_error<1e-10)
write_result(patient,"recomputed_patient_scores.csv")

# Replot supplied summaries; these PDFs are supporting plots, not exact manuscript layouts.
pdf(file.path(out,"model_coefficients.pdf"),width=7,height=4.8)
par(mar=c(4,6,2,1))
barplot(rev(coef$coefficient),names.arg=rev(coef$gene),horiz=TRUE,las=1,
        col="#236B8E",border=NA,xlab="Ridge Cox coefficient",main="Archived nine-gene model")
abline(v=0,col="grey40");dev.off()
perf <- read_data("cohort_performance.csv")
pdf(file.path(out,"cohort_Cindex.pdf"),width=8,height=5)
par(mar=c(4,8,3,2));yy<-rev(seq_len(nrow(perf)))
plot(perf$C_index,yy,xlim=c(0,1),ylim=c(.5,nrow(perf)+.5),yaxt="n",pch=19,
     col="#236B8E",xlab="Harrell C-index (95% CI)",ylab="",main="Fixed-score patient-level re-evaluation")
axis(2,at=yy,labels=gsub("_","-",perf$cohort),las=1)
segments(perf$C_lower,yy,perf$C_upper,yy,col="#236B8E",lwd=2)
abline(v=.5,lty=2,col="grey60");dev.off()
pdf(file.path(out,"cohort_time_dependent_AUC.pdf"),width=8,height=5)
auc<-as.matrix(perf[,c("AUC_1y","AUC_3y","AUC_5y")])
matplot(c(1,3,5),t(auc),type="b",lty=1,pch=seq_len(nrow(perf)),col=seq_len(nrow(perf)),
        ylim=c(0,1),xaxt="n",xlab="Years",ylab="Time-dependent AUC",
        main="Archived patient-level AUC estimates")
axis(1,at=c(1,3,5));abline(h=.5,lty=2,col="grey60")
legend("bottomleft",legend=gsub("_","-",perf$cohort),col=seq_len(nrow(perf)),
       pch=seq_len(nrow(perf)),lty=1,cex=.7,ncol=2,bty="n");dev.off()

checks <- data.frame(check=c("record_score_max_abs_error","patient_score_max_abs_error"),
                     value=c(score_error,patient_error))
if(requireNamespace("survival",quietly=TRUE)){
 suppressPackageStartupMessages(library(survival))
 metrics<-do.call(rbind,lapply(perf$cohort,function(id){
  d<-patient[patient$cohort==id,]
  cc<-concordance(Surv(time_days,event)~RS,data=d,reverse=TRUE)
  z<-(d$RS-mean(d$RS))/sd(d$RS)
  fit<-coxph(Surv(time_days,event)~z,data=d,ties="efron")
  sm<-summary(fit)
  data.frame(cohort=id,n_patients=nrow(d),events=sum(d$event),
             C_index=cc$concordance,HR=sm$conf.int[1,"exp(coef)"])
 }))
 j<-match(perf$cohort,metrics$cohort)
 stopifnot(all(perf$n_patients==metrics$n_patients[j]),all(perf$events==metrics$events[j]))
 c_error<-max(abs(perf$C_index-metrics$C_index[j]))
 hr_error<-max(abs(perf$HR-metrics$HR[j]))
 stopifnot(c_error<1e-10,hr_error<1e-8)
 checks<-rbind(checks,data.frame(check=c("Cindex_max_abs_error","HR_max_abs_error"),value=c(c_error,hr_error)))
 write_result(metrics,"recomputed_cohort_metrics.csv")

 clinical<-read_data("TCGA_primary_complete_cases.csv")
 clinical$pT<-factor(clinical$pT,levels=c("pT2","pT3_4"))
 clinical$pN<-factor(clinical$pN,levels=c("N0","N1"))
 fit<-coxph(Surv(time_days,event)~score_z+gleason+log2_psa+pT+pN,data=clinical,ties="efron")
 sm<-summary(fit)
 clinical_res<-data.frame(term=rownames(sm$coefficients),beta=sm$coefficients[,"coef"],
                         HR=sm$conf.int[,"exp(coef)"],lower95=sm$conf.int[,"lower .95"],
                         upper95=sm$conf.int[,"upper .95"],p=sm$coefficients[,"Pr(>|z|)"])
 write_result(clinical_res,"recomputed_primary_adjusted_Cox.csv")
 original_cox<-read_data("TCGA_Cox_results.csv")
 original_cox<-original_cox[original_cox$model=="Primary_adjusted",]
 j<-match(original_cox$term,clinical_res$term)
 stopifnot(!anyNA(j),nrow(original_cox)==nrow(clinical_res))
 clinical_error<-max(abs(original_cox$HR-clinical_res$HR[j]))
 stopifnot(clinical_error<1e-8)
 checks<-rbind(checks,data.frame(check="primary_adjusted_Cox_HR_max_abs_error",value=clinical_error))
} else {
 message("survival is unavailable: score checks and plots completed; Cox/C-index recalculation skipped.")
}
write_result(checks,"numerical_checks.csv")
writeLines(c("Recomputed stored-model scores and patient aggregation; no retraining.",
             "C-index, univariable HR and primary adjusted Cox are recalculated if survival is available.",
             "AUC plot uses provided estimates; AUC/CI estimation was not re-run here.",
             "These are supporting summary figures, not pixel-identical manuscript figure reproductions.",
             capture.output(sessionInfo())),file.path(out,"sessionInfo.txt"))
print(checks)
cat("Outputs:",out,"\n")
