# 上传说明
将本文件夹内的全部内容上传到 GitHub 即可；无需上传打包脚本或原始大型单细胞对象。

已包含四类材料：环境与版本记录、随机种子/参数、重要中间数据与现有补充表、分析代码与可运行的汇总绘图脚本。
README.md 为英文公开说明；docs/data_dictionary.csv 是数据解释；docs/script_index.csv 是脚本索引。

最简运行：在仓库根目录执行 Rscript --vanilla scripts/reproduce_selected.R .
结果位于 results/reproduced/，含风险评分重算、部分统计复算和三个汇总 PDF。

版本记录来自返修时保存的真实 sessionInfo。未保存的历史版本保留为未知，没有生成虚假的 renv.lock。若原始完整 R/Python 环境仍可使用，可以运行 environment 内的采集脚本追加真实环境文件。

审稿回复可使用根目录的 Comment11_response.md，填写 GitHub 链接后使用。应表述为公开了关键处理后数据与可用环境记录；不要写成已实现所有原始数据到所有论文图的完整复现。
