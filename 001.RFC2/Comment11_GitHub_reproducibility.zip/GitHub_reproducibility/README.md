# RFC2 prostate cancer analysis: reproducibility materials
This release provides software records, important processed data, supplementary tables, and analysis/plotting source for the revised study.

## Contents
| Directory | Contents |
|---|---|
| environment/ | Recorded software versions/session information, static dependency inventory, random seeds and settings |
| data/ | Nine-gene model inputs and coefficients, risk scores, cohort performance, clinical complete cases, patient-level single-cell summaries and compact pseudobulk counts |
| supplementary_tables/ | Two original supplements, four existing revision workbooks, dataset summary and machine-readable ML method profiles |
| analysis_code/ | Nine curated analysis modules, shared functions, input registry, rights and audit notes |
| scripts/ | Self-contained score checks and supporting figure generation |
| docs/ | Data dictionary and script index |

## Quick reproduction
From the repository root, run:

~~~sh
Rscript --vanilla scripts/reproduce_selected.R .
~~~

Base R produces risk scores and three supporting summary PDFs. With the recommended R package survival available, the script also recalculates patient-level C-indices, univariable HRs and the primary adjusted clinical Cox model. Outputs are written to results/reproduced/.

R 4.5.3 was used for this release's verification. See environment/plotting_sessionInfo.txt and results/reproduced/sessionInfo.txt for the actual package versions. Input CSVs are UTF-8; public study/sample/patient identifiers are retained to support traceability.

## Interpretation
- The stored score is RS = exp(sum(expression * coefficient)). Supplied expression values are already model-ready: do not normalize them again.
- Record-level data and patient-level data are different. Repeated records are collapsed by averaging log(RS), followed by exponentiation.
- Follow-up is in days; event=1 indicates the cohort-specific event. TCGA uses PFS. The cohort table documents the additional cohorts' endpoint labels.
- TCGA_primary_complete_cases.csv uses standardized log(RS), whereas the cross-cohort HR uses within-cohort standardized raw RS.
- The quick script replots provided AUC estimates; it does not re-estimate time-dependent AUC/CI.
- Supporting PDFs are summary replots, not exact reproductions of every manuscript layout.
- Existing supplementary workbooks are copied without changes. Dataset entries marked TBC retain unresolved provenance; no new accession, endpoint or sample count was invented.

## Scope and limitations
This is a lightweight processed-data release, not a fully validated raw-data-to-manuscript pipeline. Large raw/cell-level/spatial/drug-response objects and some external resources are not bundled. analysis_code/docs/input_objects.csv lists input requirements for the original modules. Original analysis/plotting source remains available but may require prepared inputs and interactive state.

The original complete software environment and all Python versions were not preserved; the provided version records are explicitly scoped to revision sessions. No historical lock file or complete independent model validation is claimed. Archived comparisons are exploratory; additional cohorts informed feature availability/model comparison. Three outcome-dependent subsampling loops remain blocked in the curated clinical source. See the original audit and limitations in analysis_code/docs/ before running those sections.

See analysis_code/RIGHTS.md for rights status; this release does not grant new rights to third-party data or code.
